

function App() {
  return (
    <div>
    <h1>Hello Friend</h1>
    </div>
  );
}

export default App;
